# Project 2: Automated Lead Cleaner

## Run in VS Code Terminal
```powershell
python clean_leads.py
```
