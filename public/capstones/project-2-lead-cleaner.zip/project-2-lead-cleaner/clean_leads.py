import json

def safe_spend(raw_val):
    try:
        return float(raw_val)
    except (ValueError, TypeError):
        return 0.0

def clean_batch(records):
    valid = []
    for r in records:
        email = str(r.get("email") or "").strip().lower()
        if "@" not in email:
            continue
        spend = safe_spend(r.get("spend"))
        valid.append({
            "email": email,
            "plan": str(r.get("plan") or "starter").strip().lower(),
            "spend": spend,
            "vip": spend >= 500.0,
        })
    return valid

if __name__ == "__main__":
    with open("raw_leads.json", "r", encoding="utf-8") as f:
        raw = json.load(f)
    cleaned = clean_batch(raw)
    with open("clean_leads.json", "w", encoding="utf-8") as f:
        json.dump(cleaned, f, indent=2)
    print(f"Cleaned {len(cleaned)} valid leads -> saved to clean_leads.json")
