from fastapi.testclient import TestClient
from app.main import app, SEEN_HASHES

client = TestClient(app)

def setup_function():
    SEEN_HASHES.clear()

def test_clean_invoice_approved():
    r = client.post("/extract/verify", json={
        "vendor": "Acme Cloud",
        "invoice_no": "INV-100",
        "items": [{"description": "Seats", "amount": 200.0}, {"description": "Support", "amount": 50.0}],
        "total": 250.0,
        "confidence": 0.93,
    })
    assert r.status_code == 200
    assert r.json()["status"] == "auto_approved"

def test_duplicate_blocked():
    payload = {
        "vendor": "Acme Cloud",
        "invoice_no": "INV-100",
        "items": [{"description": "Seats", "amount": 100.0}],
        "total": 100.0,
        "confidence": 0.95,
    }
    assert client.post("/extract/verify", json=payload).json()["inserted"] is True
    assert client.post("/extract/verify", json=payload).json()["status"] == "duplicate"

def test_math_mismatch_routed_to_review():
    r = client.post("/extract/verify", json={
        "vendor": "Beta",
        "invoice_no": "INV-200",
        "items": [{"description": "Item", "amount": 80.0}],
        "total": 100.0,
        "confidence": 0.96,
    })
    assert r.json()["status"] == "needs_human_review"
    assert r.json()["reason"] == "math_mismatch"

def test_low_confidence_routed_to_review():
    r = client.post("/extract/verify", json={
        "vendor": "Gamma",
        "invoice_no": "INV-300",
        "items": [{"description": "Item", "amount": 50.0}],
        "total": 50.0,
        "confidence": 0.70,
    })
    assert r.json()["reason"] == "low_confidence"
