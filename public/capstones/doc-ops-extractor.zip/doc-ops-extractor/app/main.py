import hashlib
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="doc-ops-extractor")
SEEN_HASHES: set[str] = set()

class LineItem(BaseModel):
    description: str
    amount: float

class InvoiceIn(BaseModel):
    vendor: str
    invoice_no: str
    items: list[LineItem]
    total: float = Field(ge=0)
    confidence: float = Field(ge=0, le=1)

@app.post("/extract/verify")
def verify_and_ingest(inv: InvoiceIn) -> dict:
    key = f"{inv.vendor.strip().lower()}|{inv.invoice_no.strip()}|{inv.total:.2f}"
    doc_hash = hashlib.sha256(key.encode("utf-8")).hexdigest()
    if doc_hash in SEEN_HASHES:
        return {"inserted": False, "status": "duplicate", "doc_hash": doc_hash}

    calc_sum = round(sum(i.amount for i in inv.items), 2)
    if abs(calc_sum - inv.total) > 0.02:
        return {"inserted": False, "status": "needs_human_review", "reason": "math_mismatch", "doc_hash": doc_hash}
    if inv.confidence < 0.85:
        return {"inserted": False, "status": "needs_human_review", "reason": "low_confidence", "doc_hash": doc_hash}

    SEEN_HASHES.add(doc_hash)
    return {"inserted": True, "status": "auto_approved", "doc_hash": doc_hash}
