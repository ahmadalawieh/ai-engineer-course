# doc-ops-extractor (System 1)

## Quickstart
```bash
python -m venv .venv
# Activate venv, then:
pip install -r requirements.txt
python validator.py
```
