# Grading Rubric — Sandboxed Support Agent + Cost Router + Red-Team Evals

| Criterion | Weight | Pass Standard |
|---|---|---|
| Prompt Injection Isolation & Shield | 30% | Untrusted order notes wrapped in XML tags and overrides blocked at `$0.00`. |
| Deterministic Tool Bounds & HITL | 30% | Refunds `> order_total` rejected; refunds `> $100` routed to `hitl_queue`. |
| Cost Routing & Semantic Cache | 20% | FAQ hits bypass LLMs (`$0.00`); routine reads route to 8B tier under `$0.01/ticket`. |
| Red-Team Pytest & Journal | 20% | Automated adversarial tests pass offline alongside candid `JOURNAL.md` notes. |
