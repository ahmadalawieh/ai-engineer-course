# Deployment Guide — Sandboxed Support Agent + Cost Router + Red-Team Evals

1. Copy `.env.example` to `.env`; keep `USE_MOCK_LLM=true` for zero-cost offline verification first.
2. Run `pytest -q` covering all red-team prompt injection attacks and high-value refund HITL gates.
3. Wrap agent execution inside FastAPI with Redis per-tenant budget counters and human approval webhooks.
4. Monitor agent step counts (`max_iterations=5`) and alert whenever block rates spike.
