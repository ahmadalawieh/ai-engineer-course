from dataclasses import dataclass

@dataclass
class AgentTrace:
    route: str
    cost_usd: float
    action: str
    status: str

FAQ_CACHE = {"reset password": "Open Settings -> Security -> Reset Password."}

def run_support_agent(query: str, order_total: float, requested_refund: float = 0.0) -> AgentTrace:
    q = query.strip().lower()
    if "ignore policy" in q or "system override" in q:
        return AgentTrace("shield", 0.0, "blocked", "BLOCKED_INJECTION")
    if q in FAQ_CACHE:
        return AgentTrace("cache", 0.0, FAQ_CACHE[q], "RESOLVED")
    if requested_refund > 0:
        if requested_refund > order_total:
            return AgentTrace("validator", 0.002, "rejected_over_total", "REJECTED")
        if requested_refund > 100:
            return AgentTrace("hitl_queue", 0.003, "queued_for_human", "NEEDS_HUMAN_APPROVAL")
        return AgentTrace("mini_tool", 0.003, f"refunded_${requested_refund:.2f}", "RESOLVED")
    return AgentTrace("frontier_rag", 0.04, "complex_policy_answer", "RESOLVED")