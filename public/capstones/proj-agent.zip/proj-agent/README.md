# Sandboxed Support Agent + Red-Team Suite

## Quickstart
```bash
pip install -r requirements.txt
pytest -q
```