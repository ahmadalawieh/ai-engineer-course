# Project Journal — Support Agent

## Key Security Tradeoff
- Deterministic Python parameter validators catch out-of-bounds refund requests even if a future prompt update weakens model refusals.