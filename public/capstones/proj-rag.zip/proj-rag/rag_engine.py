import math, re
from collections import Counter

def tokenize(text: str) -> list[str]:
    return re.findall(r"[a-z0-9]+", text.lower())

def rrf_fuse(rank_a: list[str], rank_b: list[str], k: int = 60) -> list[str]:
    scores: dict[str, float] = {}
    for ranking in (rank_a, rank_b):
        for idx, doc_id in enumerate(ranking):
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (k + idx + 1)
    return sorted(scores, key=lambda d: scores[d], reverse=True)

def retrieve_hybrid(query: str, docs: list[dict], tenant_id: str, top_k: int = 3) -> list[dict]:
    # 1. Mandatory ACL pre-filter BEFORE ranking
    allowed = [d for d in docs if d["tenant_id"] in (tenant_id, "public")]
    q_tokens = Counter(tokenize(query))
    bm25_ranked = sorted(
        allowed,
        key=lambda d: sum(q_tokens[t] for t in tokenize(d["text"])),
        reverse=True,
    )
    semantic_ranked = sorted(allowed, key=lambda d: d.get("semantic_sim", 0.0), reverse=True)
    fused_ids = rrf_fuse([d["id"] for d in bm25_ranked], [d["id"] for d in semantic_ranked])[:top_k]
    by_id = {d["id"]: d for d in allowed}
    return [by_id[i] for i in fused_ids]