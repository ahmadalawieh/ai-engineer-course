# Deployment Guide — Multi-Tenant Hybrid RAG Copilot + CI Evals

1. Configure `.env` from `.env.example` (leave `OPENAI_API_KEY` empty initially to test offline mock mode).
2. Run `python eval_rag.py` and `pytest -q` confirming 0 cross-tenant leaks and Recall@2 >= 0.85.
3. For production, index embeddings into Postgres `pgvector` (`WHERE tenant_id = $1`) or Qdrant with payload ACL filtering.
4. Deploy FastAPI backend on Render/Railway and Next.js citation UI on Vercel.
