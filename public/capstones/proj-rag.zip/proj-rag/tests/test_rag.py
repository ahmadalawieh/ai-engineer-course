from eval_rag import DOCS
from rag_engine import retrieve_hybrid

def test_acl_isolation_and_exact_sku_match():
    res = retrieve_hybrid("E-402 refund discount", DOCS, "acme", top_k=2)
    ids = [d["id"] for d in res]
    assert "beta_secret" not in ids
    assert ids[0] == "acme_refund"