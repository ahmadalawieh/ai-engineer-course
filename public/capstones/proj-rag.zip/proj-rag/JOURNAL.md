# Project Journal — Hybrid RAG Copilot

## Key Lesson
- Moving tenant_id filtering before top_k selection prevented high-similarity documents from Beta Corp from ever crowding out Acme results.