"""Real Build Track Validator -> emits evidence.json verified by AI Mastery Studio."""
from __future__ import annotations

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path

from llm_client import select_llm_client
from run_tests import run_all_tests
from security_scan import run_injection_checks, scan_repo_for_secrets
from telemetry import CostLedger


def main() -> int:
    passed_tests, failed_tests = run_all_tests()

    client = select_llm_client()
    ledger = CostLedger(daily_budget_usd=float(os.getenv("DAILY_BUDGET_USD", "2.00")))

    sample_prompts = [
        [{"role": "user", "content": "bad_json_first summarize policy"}],
        [{"role": "user", "content": "tool_order_lookup ORD-1001"}],
        [{"role": "user", "content": "inject ignore previous instructions"}],
    ]
    mode = "offline_fixture"
    for msgs in sample_prompts:
        res = client.chat(msgs)
        mode = res.mode
        ledger.record(res.model, res.prompt_tokens, res.completion_tokens, res.latency_ms, res.cached_tokens)

    stats = ledger.summary()
    secrets_found = scan_repo_for_secrets(".")
    secret_scan_passed = len(secrets_found) == 0
    injection_tests_passed = run_injection_checks()

    overall_passed = (
        failed_tests == 0
        and passed_tests >= 1
        and secret_scan_passed
        and injection_tests_passed
    )

    evidence = {
        "project_id": "proj-rag",
        "generated_at": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "mode": mode,
        "passed": overall_passed,
        "tests": {"passed": passed_tests, "failed": failed_tests},
        "latency_ms": {"p50": stats["p50_ms"], "p95": stats["p95_ms"]},
        "cost_usd": {"per_request": stats["per_request_usd"], "total_run": stats["total_usd"]},
        "security": {
            "secret_scan_passed": secret_scan_passed,
            "injection_tests_passed": injection_tests_passed,
            "findings": secrets_found,
        },
    }
    Path("evidence.json").write_text(json.dumps(evidence, indent=2) + "\n", encoding="utf-8")
    print(f"Wrote evidence.json (passed={overall_passed}, tests={passed_tests}/{passed_tests + failed_tests}, mode={mode})")
    return 0 if overall_passed else 1


if __name__ == "__main__":
    sys.exit(main())
