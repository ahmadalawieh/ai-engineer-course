from rag_engine import retrieve_hybrid

DOCS = [
    {"id": "acme_refund", "tenant_id": "acme", "text": "Refund window for SKU E-402 is 14 days.", "semantic_sim": 0.89},
    {"id": "beta_secret", "tenant_id": "beta", "text": "Beta Corp secret internal discount 40%.", "semantic_sim": 0.99},
    {"id": "public_faq", "tenant_id": "public", "text": "Support hours are 9am-5pm UTC.", "semantic_sim": 0.65},
]

GOLDEN = [
    {"query": "E-402 refund policy", "tenant_id": "acme", "expected": "acme_refund"},
    {"query": "Support hours", "tenant_id": "acme", "expected": "public_faq"},
]

if __name__ == "__main__":
    hits = 0
    for case in GOLDEN:
        top = retrieve_hybrid(case["query"], DOCS, case["tenant_id"], top_k=2)
        top_ids = [d["id"] for d in top]
        assert "beta_secret" not in top_ids, "ACL security leak!"
        if case["expected"] in top_ids:
            hits += 1
    recall = hits / len(GOLDEN)
    print(f"Recall@2: {recall:.2f} | Cross-Tenant Leaks: 0")
    assert recall >= 0.85