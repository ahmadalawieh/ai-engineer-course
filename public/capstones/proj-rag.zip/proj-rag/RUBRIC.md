# Grading Rubric — Multi-Tenant Hybrid RAG Copilot + CI Evals

| Criterion | Weight | Pass Standard |
|---|---|---|
| Mandatory Tenant ACL Pre-Filtering | 30% | Filters `tenant_id` BEFORE ranking—0 cross-tenant leaks under adversarial tests. |
| Hybrid BM25 + Semantic RRF Retrieval | 25% | Captures both exact SKU error codes (`E-402`) and natural-language synonyms. |
| Grounded Citations & Refusal Behavior | 25% | 100% cited IDs exist inside retrieved top-k context; abstains when absent. |
| Automated CI Golden Eval Gate | 20% | `eval_rag.py` and `pytest` pass offline and fail loudly if recall drops. |
