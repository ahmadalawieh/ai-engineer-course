# Multi-Tenant Hybrid RAG Copilot

## Highlights
- Mandatory `tenant_id` pre-filtering before ranking (zero cross-tenant leaks).
- Hybrid keyword + semantic RRF fusion for exact SKUs + natural language questions.
- Automated Golden CI Eval asserting Recall@5 >= 0.85 and 100% Citation Validity.