# Project 1: Freelance Quote Calculator

## Run in VS Code Terminal (Windows)
```powershell
python quote_tool.py
```
