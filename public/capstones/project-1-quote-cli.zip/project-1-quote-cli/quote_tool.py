client_name = input("Client name: ").strip() or "Acme Corp"
hours = float(input("Estimated hours (e.g. 8): ") or 8)
hourly_rate = 65.0
is_rush = input("Rush delivery? (y/n): ").strip().lower() == "y"

subtotal = hours * hourly_rate
if subtotal >= 500:
    subtotal = subtotal * 0.90
    print("Applied 10% VIP project discount!")

if is_rush:
    subtotal = subtotal + 100.0
    print("Added $100 rush delivery fee.")

grand_total = round(subtotal * 1.08, 2)
print(f"Quote for {client_name}: ${grand_total} (includes 8% tax)")
