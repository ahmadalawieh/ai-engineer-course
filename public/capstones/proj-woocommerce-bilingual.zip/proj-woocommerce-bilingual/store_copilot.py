import re, unicodedata

def norm_ar_en(text: str) -> str:
    s = unicodedata.normalize("NFKC", text).lower()
    s = re.sub(r"[\u0640\u064b-\u065f\u0670]", "", s)
    return re.sub(r"[أإآ]", "ا", s).replace("ى", "ي").replace("ة", "ه")

def search_catalog(query: str, products: list[dict]) -> list[str]:
    q_toks = set(re.findall(r"[\w]+", norm_ar_en(query)))
    scored = []
    for p in products:
        hay = norm_ar_en(f"{p.get('title_en', '')} {p.get('title_ar', '')} {p.get('sku', '')}")
        hits = len(q_toks & set(re.findall(r"[\w]+", hay)))
        if hits > 0:
            scored.append((hits, p["id"]))
    scored.sort(key=lambda x: (-x[0], x[1]))
    return [pid for _, pid in scored]

def lookup_order_status(order_id: str, caller_email: str, orders: dict[str, dict]) -> dict:
    order = orders.get(order_id)
    if not order:
        return {"ok": False, "code": 404, "error": "order_not_found"}
    if order["email"].strip().lower() != caller_email.strip().lower():
        return {"ok": False, "code": 403, "error": "forbidden_cross_customer"}
    return {"ok": True, "code": 200, "order_id": order_id, "status": order["status"], "total_usd": order["total_usd"]}

def propose_refund(order_id: str, caller_email: str, requested_usd: float, orders: dict[str, dict], hitl_threshold: float = 100.0) -> dict:
    order = orders.get(order_id)
    if not order or order["email"].strip().lower() != caller_email.strip().lower():
        return {"status": "FORBIDDEN", "approved": False}
    if requested_usd <= 0 or requested_usd > float(order["total_usd"]):
        return {"status": "REJECTED_INVALID_AMOUNT", "approved": False}
    if requested_usd > hitl_threshold:
        return {"status": "NEEDS_HUMAN_APPROVAL", "approved": False}
    return {"status": "APPROVED", "approved": True, "amount_usd": round(requested_usd, 2)}