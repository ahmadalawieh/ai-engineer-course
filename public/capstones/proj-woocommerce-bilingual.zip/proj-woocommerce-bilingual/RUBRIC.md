# Grading Rubric — Bilingual (AR/EN) WooCommerce Product & Order-Status Copilot

| Criterion | Weight | Pass Standard |
|---|---|---|
| Symmetric AR/EN Catalog Search & Normalization | 25% | Finds Arabic diacritic/Alef variations and English SKUs cleanly above 90% Recall@3. |
| Authenticated Order-Status Ownership Check | 30% | Verifies caller identity (`customer_email`) before returning order status (`FORBIDDEN` on mismatch). |
| Refund Bounds & HITL Escalation | 25% | Rejects negative/excessive amounts and escalates refunds > $100 to `NEEDS_HUMAN_APPROVAL`. |
| Arabic Parity Eval & Cost Ledger | 20% | Emits passing `evidence.json` showing EN/AR parity and unit request cost tracking. |
