from eval_parity import evaluate_bilingual_parity
from store_copilot import lookup_order_status, propose_refund

ORDERS = {"ORD-1": {"email": "nadia@shop.test", "status": "DELIVERED", "total_usd": 180.0}}

def test_order_acl_and_refund_hitl():
    assert lookup_order_status("ORD-1", "other@shop.test", ORDERS)["code"] == 403
    assert lookup_order_status("ORD-1", "nadia@shop.test", ORDERS)["status"] == "DELIVERED"
    assert propose_refund("ORD-1", "nadia@shop.test", 250.0, ORDERS)["status"] == "REJECTED_INVALID_AMOUNT"
    assert propose_refund("ORD-1", "nadia@shop.test", 150.0, ORDERS)["status"] == "NEEDS_HUMAN_APPROVAL"
    assert propose_refund("ORD-1", "nadia@shop.test", 40.0, ORDERS)["status"] == "APPROVED"

def test_en_ar_parity():
    res = evaluate_bilingual_parity()
    assert res["parity_ok"] is True