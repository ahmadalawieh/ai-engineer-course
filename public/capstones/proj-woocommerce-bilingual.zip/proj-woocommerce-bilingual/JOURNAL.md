# Project Journal — Bilingual WooCommerce Copilot

## Lessons Learned
- Passing caller email from authenticated session rather than LLM tool arguments eliminates IDOR leaks across shoppers.