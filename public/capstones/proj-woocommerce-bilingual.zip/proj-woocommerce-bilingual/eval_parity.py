from store_copilot import search_catalog

PRODUCTS = [
    {"id": "p-grinder", "sku": "ESP-101", "title_en": "Espresso Grinder Pro", "title_ar": "مطحنةُ الإسبريسو"},
    {"id": "p-kettle", "sku": "KET-202", "title_en": "Electric Gooseneck Kettle", "title_ar": "غلايةُ ماءٍ كهربائيةٌ"},
]

def evaluate_bilingual_parity() -> dict:
    en_hit = "p-grinder" in search_catalog("espresso grinder", PRODUCTS)
    ar_hit = "p-grinder" in search_catalog("مطحنه الاسبريسو", PRODUCTS)
    return {"en_recall": 1.0 if en_hit else 0.0, "ar_recall": 1.0 if ar_hit else 0.0, "parity_ok": en_hit and ar_hit}