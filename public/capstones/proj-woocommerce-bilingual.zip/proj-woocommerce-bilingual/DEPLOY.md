# Deployment Guide — Bilingual (AR/EN) WooCommerce Product & Order-Status Copilot

1. Run `make test` and `make check` offline first to verify customer permission checks, Arabic parity evals, and generate `evidence.json`.
2. Connect a real store webhook/REST read token or test sandbox, plus local Ollama or an OpenAI-compatible key for `make live`.
3. Deploy the FastAPI tool gateway on Render/Fly and verify RTL/LTR product card citations inside Next.js (`dir="auto"`).
