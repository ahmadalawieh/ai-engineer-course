from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.metrics import roc_auc_score
from train_pipeline import build_pipeline, choose_best_threshold, make_sample_dataset

def test_cv_beats_random():
    df = make_sample_dataset(600, seed=42)
    X, y = df.drop(columns=["churned"]), df["churned"].to_numpy()
    pipe = build_pipeline(["days_inactive", "tickets_30d"], ["plan"])
    oof = cross_val_predict(pipe, X, y, cv=StratifiedKFold(3, shuffle=True, random_state=42), method="predict_proba")[:, 1]
    assert roc_auc_score(y, oof) > 0.70
    t, net = choose_best_threshold(y, oof)
    assert 0.15 <= t <= 0.85 and net > 0