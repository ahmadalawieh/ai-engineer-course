# Grading Rubric — End-to-End Customer Churn & Profit Engine

| Criterion | Weight | Pass Standard |
|---|---|---|
| Leak-Free CV & Pipeline Isolation | 30% | All scalers/imputers sit inside Scikit-Learn `Pipeline` across `StratifiedKFold` folds. |
| Model Calibration & Metrics | 25% | Reports out-of-fold ROC-AUC >= 0.71 and PR-AUC (never raw accuracy only). |
| Profit Decision Thresholding | 25% | Threshold optimizes `TP * LTV_saved - sent * offer_cost` rather than 0.50 default. |
| Offline Pytest Suite & Docs | 20% | `pytest -q` passes cleanly plus completed `README.md` and `JOURNAL.md`. |
