# Customer Churn & Retention ROI Engine

## Architecture
1. Feature extraction via leak-free observation windows (no post-churn attributes).
2. Scikit-Learn `ColumnTransformer` + `XGBClassifier` inside 5-fold Stratified CV.
3. Expected-Value decision thresholding to target persuadable accounts.

## Quickstart
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
python train_pipeline.py
pytest -q
```