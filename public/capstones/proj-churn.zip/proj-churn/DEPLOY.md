# Deployment Guide — End-to-End Customer Churn & Profit Engine

1. Create `.venv` and run `pip install -r requirements.txt`.
2. Execute `python train_pipeline.py` to verify 5-fold stratified CV ROC-AUC (>0.71) and profit threshold.
3. Wrap inference behind a FastAPI `/predict` endpoint or Streamlit/Gradio dashboard on Render/HuggingFace Spaces free tier.
4. Configure GitHub Actions CI running `pytest -q` on every PR before pushing updates live.
