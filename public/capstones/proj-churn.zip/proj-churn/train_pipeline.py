import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.metrics import average_precision_score, roc_auc_score
from sklearn.model_selection import StratifiedKFold, cross_val_predict
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler

try:
    from xgboost import XGBClassifier
except ImportError:
    from sklearn.ensemble import GradientBoostingClassifier
    XGBClassifier = None

def make_sample_dataset(n: int = 400, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    days_inactive = rng.integers(1, 45, size=n)
    tickets_30d = rng.integers(0, 8, size=n)
    plan = rng.choice(["free", "pro", "team"], size=n, p=[0.4, 0.4, 0.2])
    risk = 0.06 * days_inactive + 0.35 * tickets_30d - np.where(plan == "team", 1.1, 0.0) - 2.0
    prob = 1 / (1 + np.exp(-risk))
    churned = rng.binomial(1, prob)
    return pd.DataFrame({
        "days_inactive": days_inactive,
        "tickets_30d": tickets_30d,
        "plan": plan,
        "churned": churned,
    })

def build_pipeline(num_cols: list[str], cat_cols: list[str]) -> Pipeline:
    pre = ColumnTransformer([
        ("num", Pipeline([("imp", SimpleImputer(strategy="median")), ("sc", StandardScaler())]), num_cols),
        ("cat", Pipeline([("imp", SimpleImputer(strategy="most_frequent")), ("ohe", OneHotEncoder(handle_unknown="ignore"))]), cat_cols),
    ])
    clf = (
        XGBClassifier(n_estimators=150, max_depth=4, learning_rate=0.05, eval_metric="logloss", random_state=42)
        if XGBClassifier is not None
        else GradientBoostingClassifier(n_estimators=80, max_depth=3, random_state=42)
    )
    return Pipeline([
        ("pre", pre),
        ("clf", clf),
    ])

def choose_best_threshold(y_true: np.ndarray, probs: np.ndarray, save_value: float = 120.0, offer_cost: float = 20.0):
    best_t, best_net = 0.5, -1e9
    for t in np.linspace(0.15, 0.85, 29):
        send = probs >= t
        tp = np.sum((send == 1) & (y_true == 1))
        total_sent = np.sum(send)
        net = tp * save_value - total_sent * offer_cost
        if net > best_net:
            best_net, best_t = float(net), float(t)
    return best_t, best_net

if __name__ == "__main__":
    df = make_sample_dataset()
    X, y = df.drop(columns=["churned"]), df["churned"].to_numpy()
    pipe = build_pipeline(["days_inactive", "tickets_30d"], ["plan"])
    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
    oof = cross_val_predict(pipe, X, y, cv=cv, method="predict_proba")[:, 1]
    t, net = choose_best_threshold(y, oof)
    print(f"ROC-AUC: {roc_auc_score(y, oof):.3f} | PR-AUC: {average_precision_score(y, oof):.3f} | Best Threshold: {t:.2f} (Net +${net:.0f})")