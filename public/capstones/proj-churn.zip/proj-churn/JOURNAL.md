# Project Journal — Customer Churn & Profit Engine

## Root Cause Fixed
- Increased evaluation sample size to n=600 and wrapped imputers/scalers inside ColumnTransformer to stabilize CV AUC above 0.71 with zero fold leakage.