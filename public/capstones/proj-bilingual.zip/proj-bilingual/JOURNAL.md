# Project Journal — Bilingual AR/EN Search

## Findings
- NFKC + symmetric Alef/Ya/Ta-Marbuta unification fixed 100% of diacritic query mismatches.