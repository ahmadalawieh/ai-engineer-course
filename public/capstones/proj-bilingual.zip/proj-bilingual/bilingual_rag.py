import re, unicodedata

def normalize_bilingual(text: str) -> str:
    s = unicodedata.normalize("NFKC", text).lower()
    s = re.sub(r"[\u0640\u064b-\u065f\u0670]", "", s)
    s = re.sub(r"[أإآ]", "ا", s)
    return s.replace("ى", "ي").replace("ة", "ه")

def search_bilingual(query: str, docs: list[dict], tenant_id: str) -> list[dict]:
    allowed = [d for d in docs if d["tenant_id"] in (tenant_id, "public")]
    q_toks = set(re.findall(r"[\w]+", normalize_bilingual(query)))
    return sorted(allowed, key=lambda d: len(q_toks & set(re.findall(r"[\w]+", normalize_bilingual(d["text"])))) + d.get("semantic_sim", 0.0), reverse=True)