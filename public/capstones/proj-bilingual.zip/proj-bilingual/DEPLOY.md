# Deployment Guide — Bilingual (Arabic / English) RTL Support Search Assistant

1. Test bilingual normalization and search locally via `python bilingual_rag.py` and `pytest -q`.
2. Deploy backend API cleanly on Render/Fly alongside a Next.js RTL-aware UI (`dir="auto"` per message bubble) on Vercel.
3. Verify both English and Arabic golden evaluation slices score >= 85% Recall before shipping.
