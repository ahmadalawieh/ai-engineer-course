from bilingual_rag import normalize_bilingual, search_bilingual

def test_arabic_diacritic_and_acl_parity():
    assert normalize_bilingual("الإرجاعُ") == normalize_bilingual("الارجاع")
    docs = [{"id": "a1", "tenant_id": "t1", "text": "الإرجاع خلال ١٤ يوماً", "semantic_sim": 0.9}, {"id": "b1", "tenant_id": "t2", "text": "بيانات سرية", "semantic_sim": 0.99}]
    res = search_bilingual("الارجاع", docs, "t1")
    assert [d["id"] for d in res] == ["a1"]