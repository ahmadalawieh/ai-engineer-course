# Grading Rubric — Bilingual (Arabic / English) RTL Support Search Assistant

| Criterion | Weight | Pass Standard |
|---|---|---|
| Symmetric Arabic Normalization | 30% | Strips Tashkeel diacritics and unifies Alef/Ya/Ta-Marbuta symmetrically on index & query. |
| Bilingual Hybrid Retrieval & Tenant ACL | 30% | Pre-filters `tenant_id` cleanly and fuses keyword + semantic scores accurately. |
| RTL UI & Citation Provenance | 20% | Renders mixed Arabic/English citations cleanly with `dir="auto"` isolation. |
| Bilingual Eval Parity & Tests | 20% | Offline `pytest` proves equal retrieval recall on EN and AR test queries. |
