# Bilingual Arabic / English RTL Support Search Assistant

## Quickstart
```bash
pip install -r requirements.txt
pytest -q
```

## Real Build Track (Local & Live Provider Execution)

1. **Offline Verified Replay (Zero API Cost):**
   ```bash
   make test    # Runs unit + fixture replay tests offline
   make check   # Emits evidence.json for Practice Arena -> Evidence Pack
   ```
2. **Free Local Model via Ollama:**
   ```bash
   ollama pull qwen2.5:7b-instruct
   LLM_MODE=live LLM_BASE_URL=http://localhost:11434/v1 LLM_MODEL=qwen2.5:7b-instruct make live
   ```
3. **Hosted OpenAI-Compatible Provider:**
   - Set `LLM_BASE_URL=https://api.openai.com/v1`, `LLM_API_KEY=your-key`, and a Small-Fast tier model name in `.env`.
   - Illustrative API cost: a single live validation run (~3–5 short turns) consumes ~2,500 tokens, typically **under $0.02** on Small-Fast tier models (check your provider's pricing page). Never commit `.env`.
