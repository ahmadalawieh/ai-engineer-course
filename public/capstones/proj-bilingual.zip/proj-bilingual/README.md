# Bilingual Arabic / English RTL Support Search Assistant

## Quickstart
```bash
pip install -r requirements.txt
pytest -q
```