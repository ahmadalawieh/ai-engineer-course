# tenant-rag-copilot (System 2)

## Quickstart
```bash
pip install -r requirements.txt
python validator.py
```
