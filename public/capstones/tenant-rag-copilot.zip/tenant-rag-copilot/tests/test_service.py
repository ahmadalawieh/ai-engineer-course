from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_cross_tenant_blocked():
    r = client.post("/rag/query", json={"tenant_id": "acme", "user_roles": ["member"], "citations": ["acme-pol-1"]}).json()
    ids = [c["id"] for c in r["chunks"]]
    assert "beta-pol-1" not in ids
    assert r["abstain"] is False

def test_admin_role_isolated():
    r = client.post("/rag/query", json={"tenant_id": "acme", "user_roles": ["member"], "citations": ["acme-pol-1"]}).json()
    ids = [c["id"] for c in r["chunks"]]
    assert "acme-exec" not in ids

def test_phantom_citation_abstains():
    r = client.post("/rag/query", json={"tenant_id": "acme", "user_roles": ["member"], "citations": ["beta-pol-1"]}).json()
    assert r["abstain"] is True

def test_unknown_tenant_abstains():
    r = client.post("/rag/query", json={"tenant_id": "none", "user_roles": ["member"], "citations": ["x"]}).json()
    assert r["abstain"] is True
