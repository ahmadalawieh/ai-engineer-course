from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="tenant-rag-copilot")

CHUNKS = [
    {"id": "acme-pol-1", "tenant_id": "acme", "roles": ["member", "admin"], "text": "Refunds within 30 days.", "score": 0.91},
    {"id": "acme-exec", "tenant_id": "acme", "roles": ["admin"], "text": "M&A roadmap confidential.", "score": 0.97},
    {"id": "beta-pol-1", "tenant_id": "beta", "roles": ["member"], "text": "Beta 90-day refund.", "score": 0.99},
]

class QueryReq(BaseModel):
    tenant_id: str
    user_roles: list[str]
    citations: list[str]

@app.post("/rag/query")
def query_copilot(req: QueryReq) -> dict:
    role_set = set(req.user_roles)
    allowed = [
        c for c in CHUNKS
        if c["tenant_id"] == req.tenant_id and (set(c["roles"]) & role_set)
    ]
    allowed.sort(key=lambda c: c["score"], reverse=True)
    if not allowed or allowed[0]["score"] < 0.65:
        return {"abstain": True, "chunks": []}
    valid_ids = {c["id"] for c in allowed}
    if not req.citations or not set(req.citations).issubset(valid_ids):
        return {"abstain": True, "reason": "unverified_citation", "chunks": allowed}
    return {"abstain": False, "chunks": allowed, "verified_citations": req.citations}
