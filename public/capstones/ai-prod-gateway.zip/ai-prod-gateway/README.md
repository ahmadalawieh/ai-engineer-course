# ai-prod-gateway (System 4)

## Quickstart
```bash
pip install -r requirements.txt
python validator.py
```
