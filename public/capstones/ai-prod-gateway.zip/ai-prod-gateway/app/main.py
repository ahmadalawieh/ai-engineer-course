import re
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="ai-prod-gateway")

class GatewayReq(BaseModel):
    prompt: str
    complexity: str = "low"
    spent_usd: float = 0.0
    daily_cap_usd: float = 10.0
    unhealthy_models: list[str] = []

@app.post("/v1/chat")
def gateway_route(req: GatewayReq) -> dict:
    if req.spent_usd >= req.daily_cap_usd:
        return {"allowed": False, "reason": "budget_exceeded"}
    low = req.prompt.lower()
    if "ignore previous instructions" in low or "reveal system prompt" in low:
        return {"allowed": False, "reason": "prompt_injection_blocked"}
    clean_prompt = re.sub(r"[\w.+-]+@[\w-]+\.[\w.-]+", "[EMAIL_REDACTED]", req.prompt)
    model = "frontier-reasoning" if req.complexity == "high" else "small-fast"
    if model in set(req.unhealthy_models):
        model = "backup-mid"
    return {"allowed": True, "model": model, "clean_prompt": clean_prompt}
