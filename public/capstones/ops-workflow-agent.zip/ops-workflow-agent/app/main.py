from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="ops-workflow-agent")
LEDGER: dict[str, dict] = {}

class StepReq(BaseModel):
    run_id: str
    step: int
    action: str
    target_id: str
    amount: float = 0.0

@app.post("/agent/step")
def run_agent_step(req: StepReq) -> dict:
    if req.step > 6:
        return {"status": "halted", "reason": "max_steps_exceeded"}
    if req.action == "delete_account" or (req.action == "issue_refund" and req.amount > 50.0):
        return {"status": "pending_approval", "checkpoint_id": f"chk_{req.run_id}_{req.target_id}"}
    key = f"{req.run_id}:{req.action}:{req.target_id}"
    if key in LEDGER:
        return {"status": "cached", "idempotency_key": key}
    res = {"status": "executed", "idempotency_key": key}
    LEDGER[key] = res
    return res
