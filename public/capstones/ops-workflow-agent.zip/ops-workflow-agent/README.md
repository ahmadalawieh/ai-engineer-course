# ops-workflow-agent (System 3)

## Quickstart
```bash
pip install -r requirements.txt
python validator.py
```
