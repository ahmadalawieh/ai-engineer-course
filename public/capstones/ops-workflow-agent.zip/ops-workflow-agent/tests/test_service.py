from fastapi.testclient import TestClient
from app.main import app, LEDGER

client = TestClient(app)

def setup_function():
    LEDGER.clear()

def test_low_value_refund_executes():
    r = client.post("/agent/step", json={"run_id": "r1", "step": 1, "action": "issue_refund", "target_id": "ORD-1", "amount": 20.0})
    assert r.json()["status"] == "executed"

def test_duplicate_retry_cached():
    payload = {"run_id": "r1", "step": 1, "action": "issue_refund", "target_id": "ORD-1", "amount": 20.0}
    client.post("/agent/step", json=payload)
    assert client.post("/agent/step", json=payload).json()["status"] == "cached"

def test_high_value_refund_hits_hitl():
    r = client.post("/agent/step", json={"run_id": "r2", "step": 2, "action": "issue_refund", "target_id": "ORD-9", "amount": 120.0})
    assert r.json()["status"] == "pending_approval"

def test_step_cap_halts_loop():
    r = client.post("/agent/step", json={"run_id": "r3", "step": 7, "action": "lookup", "target_id": "ORD-2"})
    assert r.json()["status"] == "halted"
