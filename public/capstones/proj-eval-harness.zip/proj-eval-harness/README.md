# LLM Evaluation Harness & CI Regression Gate

## Quickstart
```bash
pip install -r requirements.txt
python eval_runner.py
pytest -q
```