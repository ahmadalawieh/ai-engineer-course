# Deployment Guide — LLM Evaluation Harness & Regression Report Engine

1. Initialize `.venv` and install `pytest` (`pip install -r requirements.txt`).
2. Run `python eval_runner.py --baseline fixtures/baseline.json --candidate fixtures/candidate.json` to generate `reports/eval_report.md`.
3. Enable GitHub Actions workflow `.github/workflows/eval_gate.yml` so every pull request fails automatically if pass rate drops > 2% or citation validity < 100%.
4. Optionally configure `OPENAI_API_KEY` to run live model generation alongside recorded deterministic fixture cases.
