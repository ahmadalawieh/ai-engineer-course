# Project Journal — LLM Eval Harness

## Caught Regression
- Swapping pairwise order exposed 18% position bias in naive judge prompts; enforcing agreement dropped false wins cleanly.