# Grading Rubric — LLM Evaluation Harness & Regression Report Engine

| Criterion | Weight | Pass Standard |
|---|---|---|
| Golden Dataset Coverage & Refusal Traps | 25% | Covers happy-path, missing-evidence refusal, and JSON schema edge cases cleanly. |
| Deterministic + Debiased Judge Scoring | 30% | Checks schema/citations before running swapped `(A,B)/(B,A)` pairwise judging. |
| Regression Delta Gate & Exit Codes | 25% | Exits non-zero (`1`) on drop > tolerance and prints per-case diff report. |
| Offline CI Tests & Project Journal | 20% | Full `pytest` passes 100% offline with documented real regression catch. |
