import json, sys
from pathlib import Path

def check_case(case: dict, output: dict) -> tuple[bool, list[str]]:
    reasons = []
    if case.get("expect_refusal"):
        if not output.get("refused"):
            reasons.append("failed_to_refuse")
    else:
        allowed = set(case.get("retrieved_ids", []))
        cits = output.get("cited_ids", [])
        if not cits or not all(c in allowed for c in cits):
            reasons.append("invalid_or_missing_citations")
        for kw in case.get("must_include", []):
            if kw.lower() not in output.get("answer", "").lower():
                reasons.append(f"missing_keyword:{kw}")
    return len(reasons) == 0, reasons

def run_suite(cases: list[dict], outputs: dict[str, dict]) -> dict:
    results = {}
    for c in cases:
        ok, reasons = check_case(c, outputs.get(c["id"], {}))
        results[c["id"]] = {"passed": ok, "reasons": reasons}
    rate = sum(1 for v in results.values() if v["passed"]) / max(1, len(results))
    return {"pass_rate": round(rate, 4), "cases": results}

if __name__ == "__main__":
    sample_cases = [{"id": "g1", "retrieved_ids": ["d1"], "must_include": ["14 days"]}, {"id": "g2", "expect_refusal": True}]
    sample_out = {"g1": {"answer": "14 days.", "cited_ids": ["d1"]}, "g2": {"refused": True, "cited_ids": []}}
    report = run_suite(sample_cases, sample_out)
    print(json.dumps(report, indent=2))
    if report["pass_rate"] < 0.90:
        sys.exit(1)