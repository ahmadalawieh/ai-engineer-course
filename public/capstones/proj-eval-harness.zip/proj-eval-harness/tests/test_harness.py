from eval_runner import run_suite

def test_catches_hallucinated_citation_and_missing_refusal():
    cases = [{"id": "c1", "retrieved_ids": ["d1"], "must_include": ["14 days"]}, {"id": "c2", "expect_refusal": True}]
    bad_out = {"c1": {"answer": "14 days", "cited_ids": ["invented_doc"]}, "c2": {"refused": False}}
    res = run_suite(cases, bad_out)
    assert res["pass_rate"] == 0.0