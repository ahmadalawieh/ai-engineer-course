# Project 4: Full-Stack AI Order Support Web App

## Run Locally
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
uvicorn main:app --reload
```
Then open http://localhost:8000 in your browser!
