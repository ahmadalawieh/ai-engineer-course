import sqlite3
from fastapi import FastAPI
from fastapi.responses import FileResponse
from pydantic import BaseModel

app = FastAPI(title="AI Order Support")

def init_db():
    with sqlite3.connect("orders.db") as conn:
        conn.execute("CREATE TABLE IF NOT EXISTS orders (order_id TEXT PRIMARY KEY, status TEXT, eta TEXT)")
        conn.executemany("INSERT OR REPLACE INTO orders VALUES (?, ?, ?)", [
            ("ORD-101", "Shipped", "Arriving Thursday"),
            ("ORD-102", "Processing", "Ships tomorrow morning"),
        ])

init_db()

class AskReq(BaseModel):
    message: str

@app.get("/")
def home():
    return FileResponse("public/index.html")

@app.post("/ask")
def ask_support(req: AskReq):
    for raw in req.message.split():
        word = raw.strip(".,?!")
        if word.startswith("ORD-"):
            with sqlite3.connect("orders.db") as conn:
                row = conn.execute("SELECT status, eta FROM orders WHERE order_id = ?", (word,)).fetchone()
            if row:
                return {"reply": f"Order {word} is currently {row[0]} ({row[1]})."}
            return {"reply": f"We could not find order {word}. Please double-check the number."}
    return {"reply": "Please include your ORD- order number so I can check our database!"}
