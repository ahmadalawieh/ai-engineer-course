# Deployment Guide — FastAPI + Docker Live Deployed AI Microservice

1. Copy `.env.example` to `.env` and generate a random 32-char `SERVICE_API_KEY` (`python -c "import secrets; print(secrets.token_urlsafe(24))"`).
2. Test locally inside Docker honoring dynamic `$PORT`: `docker compose up --build`, then curl `/healthz` and `/readyz`.
3. Create a free Web Service on Render, Fly.io, or Railway linked to your GitHub repo using the root `Dockerfile`.
4. Set `SERVICE_API_KEY`, `ALLOWED_ORIGINS` (your Vercel app domain), and `DAILY_BUDGET_USD=2.0` in the host dashboard.
5. Run `python smoke_test.py --base-url YOUR_CLOUD_URL --api-key YOUR_KEY` immediately after deployment succeeds.
