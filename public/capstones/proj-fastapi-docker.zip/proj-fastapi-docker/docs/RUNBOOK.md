# On-Call Incident RUNBOOK

## 1. HTTP 503 / Upstream LLM Timeout
- Verify: Inspect JSON logs filtering `status >= 500` and `/readyz`.
- Mitigate: Toggle fallback mock/8B route via env and redeploy prior immutable tag.

## 2. Spike in HTTP 429 Rate Limits
- Verify: Check structured `tenant_id` request rates.
- Mitigate: Confirm webhook loop protection; ban runaway key if abused.