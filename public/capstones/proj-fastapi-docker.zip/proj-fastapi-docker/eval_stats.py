"""Paired bootstrap 95% confidence interval for offline evaluation regression checks."""
from __future__ import annotations

import random


def bootstrap_mean_delta_ci(
    baseline_scores: list[float],
    candidate_scores: list[float],
    n_resamples: int = 400,
    seed: int = 42,
) -> tuple[float, float, float]:
    n = min(len(baseline_scores), len(candidate_scores))
    if n == 0:
        return 0.0, 0.0, 0.0
    deltas = [candidate_scores[i] - baseline_scores[i] for i in range(n)]
    rng = random.Random(seed)
    means: list[float] = []
    for _ in range(n_resamples):
        sample = [deltas[rng.randrange(n)] for _ in range(n)]
        means.append(sum(sample) / n)
    means.sort()
    lo = means[int(0.025 * n_resamples)]
    hi = means[int(0.975 * n_resamples)]
    return round(sum(deltas) / n, 4), round(lo, 4), round(hi, 4)
