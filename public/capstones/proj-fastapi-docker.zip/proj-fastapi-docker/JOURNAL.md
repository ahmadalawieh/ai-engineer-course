# Project Journal — FastAPI + Docker AI Service

## Bugs Caught & Fixed
- Replaced naive == key comparison with hmac.compare_digest.
- Fixed Render health-check timeout by binding --port ${PORT:-8000}.