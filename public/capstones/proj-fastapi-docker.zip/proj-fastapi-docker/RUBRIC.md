# Grading Rubric — FastAPI + Docker Live Deployed AI Microservice

| Criterion | Weight | Pass Standard |
|---|---|---|
| Typed API Contracts & Health Probes | 25% | Pydantic v2 bounds (`extra="forbid"`) reject bad JSON (`422`); `/healthz` & `/readyz` distinct. |
| Constant-Time Auth, CORS & Rate Limiting | 25% | Uses `hmac.compare_digest`, blocks `*` CORS with credentials, enforces `429` limits. |
| Docker Hardening & CI Pipeline | 25% | Dependencies layered ahead of `src/`, `.dockerignore` excludes secrets, non-root `USER`, CI passes offline. |
| Live Smoke Suite, README & RUNBOOK | 25% | 5-point live smoke suite passes (`200/401/422`) + actionable rollback RUNBOOK documented. |
