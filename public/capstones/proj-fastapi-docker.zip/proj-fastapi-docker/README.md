# Production FastAPI + Docker AI Microservice

## Architecture
Client -> CORS Allowlist -> FastAPI (`/healthz`, `/readyz`, `POST /v1/ask`) -> Auth + Rate Limit -> Mock/OpenAI Engine

## Quickstart
```bash
cp .env.example .env
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
pytest -q
docker compose up --build
```