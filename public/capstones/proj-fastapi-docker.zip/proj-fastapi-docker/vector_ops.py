"""Real vector cosine similarity, Hybrid BM25 + dense RRF, Stage-2 reranking & pgvector DDL."""
from __future__ import annotations

import math
import re
from collections import Counter

PGVECTOR_SCHEMA_SQL = """
CREATE EXTENSION IF NOT EXISTS vector;
CREATE TABLE IF NOT EXISTS rag_chunks (
    id TEXT PRIMARY KEY,
    tenant_id TEXT NOT NULL,
    doc_title TEXT NOT NULL,
    content TEXT NOT NULL,
    embedding vector(1536) NOT NULL
);
CREATE INDEX IF NOT EXISTS rag_chunks_tenant_idx ON rag_chunks (tenant_id);
CREATE INDEX IF NOT EXISTS rag_chunks_hnsw_idx ON rag_chunks USING hnsw (embedding vector_cosine_ops);
"""


def cosine_similarity(a: list[float], b: list[float]) -> float:
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(y * y for y in b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


def reciprocal_rank_fusion(ranked_lists: list[list[str]], k: int = 60) -> list[str]:
    scores: dict[str, float] = {}
    for lst in ranked_lists:
        for rank, doc_id in enumerate(lst, start=1):
            scores[doc_id] = scores.get(doc_id, 0.0) + 1.0 / (k + rank)
    return [doc_id for doc_id, _ in sorted(scores.items(), key=lambda kv: (-kv[1], kv[0]))]


def stage2_rerank(query: str, docs: list[dict], top_k: int = 3) -> list[dict]:
    """Deterministic Stage-2 lexical + bigram reranker modeling Cross-Encoder precision lift."""
    q_toks = re.findall(r"[\w\-]+", query.lower())
    q_bigrams = set(zip(q_toks, q_toks[1:]))
    scored: list[tuple[float, dict]] = []
    for d in docs:
        d_toks = re.findall(r"[\w\-]+", str(d.get("text", "")).lower())
        d_counts = Counter(d_toks)
        d_bigrams = set(zip(d_toks, d_toks[1:]))
        unigram_hits = sum(1 for t in set(q_toks) if d_counts[t] > 0)
        bigram_hits = len(q_bigrams & d_bigrams) * 1.8
        score = unigram_hits + bigram_hits + float(d.get("semantic_sim", 0.0)) * 0.5
        scored.append((score, d))
    scored.sort(key=lambda item: (-item[0], str(item[1].get("id", ""))))
    return [item[1] for item in scored[:top_k]]
