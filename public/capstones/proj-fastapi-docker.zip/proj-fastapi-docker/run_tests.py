"""Unified test runner supporting both pytest and zero-dependency stdlib unittest."""
from __future__ import annotations

import importlib.util
import sys
import unittest
from pathlib import Path


def run_all_tests() -> tuple[int, int]:
    root = Path(".").resolve()
    sys.path.insert(0, str(root))

    suite = unittest.TestSuite()
    loader = unittest.TestLoader()

    extra_passed = 0
    extra_failed = 0

    test_files = sorted(set(list(root.glob("test_*.py")) + list((root / "tests").glob("test_*.py"))))
    for tf in test_files:
        mod_name = f"_cap_test_{tf.stem}"
        spec = importlib.util.spec_from_file_location(mod_name, tf)
        if spec is None or spec.loader is None:
            continue
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)

        loaded = loader.loadTestsFromModule(mod)
        suite.addTests(loaded)

        # Also execute plain pytest-style def test_*() functions
        for attr in dir(mod):
            if attr.startswith("test_") and callable(getattr(mod, attr)):
                fn = getattr(mod, attr)
                if not isinstance(fn, type):
                    try:
                        fn()
                        extra_passed += 1
                    except Exception as exc:
                        print(f"FAIL {tf.name}::{attr} -> {exc}")
                        extra_failed += 1

    runner = unittest.TextTestRunner(verbosity=1)
    res = runner.run(suite)
    total_passed = extra_passed + (res.testsRun - len(res.failures) - len(res.errors) - len(res.skipped))
    total_failed = extra_failed + len(res.failures) + len(res.errors)
    print(f"TEST SUMMARY: passed={total_passed}, failed={total_failed}, skipped={len(res.skipped)}")
    return total_passed, total_failed


if __name__ == "__main__":
    passed, failed = run_all_tests()
    sys.exit(0 if failed == 0 and passed > 0 else 1)
