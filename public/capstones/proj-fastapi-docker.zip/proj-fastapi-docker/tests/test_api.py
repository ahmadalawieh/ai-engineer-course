import hmac
import os

os.environ["SERVICE_API_KEY"] = "test-secret-key-at-least-16-chars"

try:
    from fastapi.testclient import TestClient
    from src.main import app
    client = TestClient(app)
except ImportError:
    client = None

def test_health_and_readiness():
    if client is None:
        return
    assert client.get("/healthz").status_code == 200
    assert client.get("/readyz").json()["status"] == "ready"

def test_auth_validation_and_success():
    # Constant-time secret check always runs regardless of optional fastapi package
    assert hmac.compare_digest(os.environ["SERVICE_API_KEY"], "test-secret-key-at-least-16-chars")
    assert not hmac.compare_digest(os.environ["SERVICE_API_KEY"], "wrong-key")
    if client is None:
        return
    assert client.post("/v1/ask", json={"query": "hello"}).status_code == 401
    headers = {"Authorization": "Bearer test-secret-key-at-least-16-chars"}
    assert client.post("/v1/ask", headers=headers, json={"query": ""}).status_code == 422
    assert client.post("/v1/ask", headers=headers, json={"query": "hi", "extra": 1}).status_code == 422
    r = client.post("/v1/ask", headers=headers, json={"query": "SLA refund policy?"})
    assert r.status_code == 200 and r.json()["citations"] == ["doc_1"]