import os
os.environ["SERVICE_API_KEY"] = "test-secret-key-at-least-16-chars"
from fastapi.testclient import TestClient
from src.main import app

client = TestClient(app)

def test_health_and_readiness():
    assert client.get("/healthz").status_code == 200
    assert client.get("/readyz").json()["status"] == "ready"

def test_auth_validation_and_success():
    assert client.post("/v1/ask", json={"query": "hello"}).status_code == 401
    headers = {"Authorization": "Bearer test-secret-key-at-least-16-chars"}
    assert client.post("/v1/ask", headers=headers, json={"query": ""}).status_code == 422
    assert client.post("/v1/ask", headers=headers, json={"query": "hi", "extra": 1}).status_code == 422
    r = client.post("/v1/ask", headers=headers, json={"query": "SLA refund policy?"})
    assert r.status_code == 200 and r.json()["citations"] == ["doc_1"]