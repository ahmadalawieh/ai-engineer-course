import hmac
import os
import time
from collections import deque
from fastapi import Depends, FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, ConfigDict, Field

SERVICE_KEY = os.environ.get("SERVICE_API_KEY", "").strip()
if len(SERVICE_KEY) < 16 and os.environ.get("ALLOW_DEV_BOOT") != "1":
    raise RuntimeError("SERVICE_API_KEY (>=16 chars) is required on startup")

app = FastAPI(title="AI Gateway Service", version="1.0.0")
raw_origins = [o.strip() for o in os.environ.get("ALLOWED_ORIGINS", "").split(",") if o.strip()]
if raw_origins:
    app.add_middleware(CORSMiddleware, allow_origins=raw_origins, allow_credentials=True, allow_methods=["GET", "POST"], allow_headers=["*"])

_RATE_WINDOWS: dict[str, deque[float]] = {}

class AskRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    query: str = Field(min_length=1, max_length=2000)
    top_k: int = Field(default=3, ge=1, le=10)

def require_auth(authorization: str = Header(default="")) -> str:
    if not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Bearer token")
    token = authorization[7:].strip()
    if not hmac.compare_digest(token.encode(), SERVICE_KEY.encode()):
        raise HTTPException(status_code=401, detail="Invalid API key")
    now = time.monotonic()
    q = _RATE_WINDOWS.setdefault("default", deque())
    while q and q[0] <= now - 60.0:
        q.popleft()
    if len(q) >= 30:
        raise HTTPException(status_code=429, detail="Rate limit exceeded", headers={"Retry-After": "10"})
    q.append(now)
    return "ok"

@app.get("/healthz")
def healthz():
    return {"status": "alive"}

@app.get("/readyz")
def readyz():
    return {"status": "ready"}

@app.post("/v1/ask", dependencies=[Depends(require_auth)])
def ask(req: AskRequest):
    return {"answer": f"[mock-grounded] Answered ({len(req.query)} chars, top_k={req.top_k})", "citations": ["doc_1"]}