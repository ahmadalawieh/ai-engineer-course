"""Latency percentiles (p50/p95), prefix-cache savings, and USD cost budget ledger."""
from __future__ import annotations

import math
from dataclasses import dataclass, field


# Reference illustrative rates per 1M tokens ($ input / $ cached input / $ output)
DEFAULT_MODEL_RATES_PER_1M: dict[str, tuple[float, float, float]] = {
    "replay-small-fast": (0.15, 0.0375, 0.60),
    "small-fast": (0.15, 0.0375, 0.60),
    "frontier-reasoning": (2.50, 0.625, 10.00),
}


def percentile(values: list[float], p: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    k = max(0, min(len(ordered) - 1, math.ceil((p / 100.0) * len(ordered)) - 1))
    return round(float(ordered[k]), 2)


@dataclass
class CostLedger:
    daily_budget_usd: float = 2.00
    spent_usd: float = 0.0
    latencies_ms: list[float] = field(default_factory=list)
    requests: int = 0

    def record(self, model: str, prompt_tokens: int, completion_tokens: int, latency_ms: float, cached_tokens: int = 0) -> float:
        in_rate, cached_rate, out_rate = DEFAULT_MODEL_RATES_PER_1M.get(model, (0.20, 0.05, 0.80))
        uncached = max(0, prompt_tokens - cached_tokens)
        cost = (uncached * in_rate + cached_tokens * cached_rate + completion_tokens * out_rate) / 1_000_000.0
        if self.spent_usd + cost > self.daily_budget_usd:
            raise RuntimeError(f"Budget exceeded: {self.spent_usd + cost:.4f} > {self.daily_budget_usd:.2f}")
        self.spent_usd += cost
        self.latencies_ms.append(float(latency_ms))
        self.requests += 1
        return round(cost, 6)

    def summary(self) -> dict[str, float | int]:
        avg_cost = self.spent_usd / self.requests if self.requests else 0.0
        return {
            "requests": self.requests,
            "p50_ms": percentile(self.latencies_ms, 50.0),
            "p95_ms": percentile(self.latencies_ms, 95.0),
            "per_request_usd": round(avg_cost, 6),
            "total_usd": round(self.spent_usd, 6),
        }
