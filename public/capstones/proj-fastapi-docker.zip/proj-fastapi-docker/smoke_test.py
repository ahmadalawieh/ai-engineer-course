import argparse, sys
import httpx

def run_smoke(base_url: str, api_key: str) -> None:
    base = base_url.rstrip("/")
    assert httpx.get(f"{base}/healthz", timeout=10).status_code == 200
    assert httpx.get(f"{base}/readyz", timeout=10).status_code == 200
    assert httpx.post(f"{base}/v1/ask", json={"query": "hi"}, timeout=10).status_code == 401
    hdr = {"Authorization": f"Bearer {api_key}"}
    assert httpx.post(f"{base}/v1/ask", headers=hdr, json={"query": ""}, timeout=10).status_code == 422
    r = httpx.post(f"{base}/v1/ask", headers=hdr, json={"query": "hello"}, timeout=15)
    assert r.status_code == 200 and r.json().get("answer")
    print("ALL 5 LIVE SMOKE CHECKS PASSED!")

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--base-url", required=True)
    p.add_argument("--api-key", required=True)
    args = p.parse_args()
    run_smoke(args.base_url, args.api_key)