"""OpenAI-compatible & Offline Replay LLM client for the Real Build Track.

Supports:
1) Local free Ollama (http://localhost:11434/v1)
2) Any OpenAI-compatible hosted endpoint (https://api.openai.com/v1)
3) Zero-network deterministic fixture replay (MockReplayLLMClient)
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable


@dataclass
class LLMResult:
    content: str
    model: str
    latency_ms: float
    prompt_tokens: int
    completion_tokens: int
    cached_tokens: int = 0
    tool_calls: list[dict[str, Any]] = field(default_factory=list)
    mode: str = "offline_fixture"


def parse_sse_lines(lines: Iterable[str]) -> list[str]:
    """Parse Server-Sent Events ('data: {...}') delta chunks cleanly."""
    tokens: list[str] = []
    for raw in lines:
        line = raw.strip()
        if not line.startswith("data:"):
            continue
        payload = line[5:].strip()
        if payload == "[DONE]":
            break
        try:
            obj = json.loads(payload)
            choices = obj.get("choices") or []
            if choices:
                delta = choices[0].get("delta") or {}
                piece = delta.get("content")
                if isinstance(piece, str):
                    tokens.append(piece)
        except json.JSONDecodeError:
            continue
    return tokens


def validate_json_keys(text: str, required_keys: list[str]) -> dict[str, Any]:
    obj = json.loads(text)
    if not isinstance(obj, dict):
        raise ValueError("Expected top-level JSON object")
    missing = [k for k in required_keys if k not in obj]
    if missing:
        raise ValueError(f"Missing required keys: {missing}")
    return obj


class MockReplayLLMClient:
    """Deterministic replay client backed by fixtures/recorded_llm.json."""

    def __init__(self, fixture_path: str | Path = "fixtures/recorded_llm.json", model: str = "replay-small-fast") -> None:
        self.model = model
        p = Path(fixture_path)
        self.fixtures = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {}

    def _find_case(self, messages: list[dict[str, str]]) -> dict[str, Any]:
        joined = " ".join(m.get("content", "") for m in messages).lower()
        for case in self.fixtures.get("chat_responses", []):
            if case.get("match_contains", "").lower() in joined:
                return case
        return {
            "raw_attempts": ['{"answer": "Offline fixture verified.", "citations": ["doc_1"], "confidence": 0.90}'],
            "latency_ms": 35,
            "prompt_tokens": 350,
            "cached_tokens": 180,
            "completion_tokens": 30,
        }

    def chat(self, messages: list[dict[str, str]], attempt: int = 0) -> LLMResult:
        case = self._find_case(messages)
        attempts = case.get("raw_attempts") or [case.get("final_answer", "ok")]
        idx = min(attempt, len(attempts) - 1)
        return LLMResult(
            content=attempts[idx],
            model=self.model,
            latency_ms=float(case.get("latency_ms", 35)),
            prompt_tokens=int(case.get("prompt_tokens", 350)),
            completion_tokens=int(case.get("completion_tokens", 30)),
            cached_tokens=int(case.get("cached_tokens", 0)),
            tool_calls=list(case.get("tool_calls", [])),
            mode="offline_fixture",
        )

    def chat_structured(self, messages: list[dict[str, str]], required_keys: list[str], max_repairs: int = 2) -> tuple[dict[str, Any], LLMResult]:
        last_err: Exception | None = None
        for attempt in range(max_repairs + 1):
            res = self.chat(messages, attempt=attempt)
            try:
                parsed = validate_json_keys(res.content, required_keys)
                return parsed, res
            except (json.JSONDecodeError, ValueError) as exc:
                last_err = exc
                messages = [*messages, {"role": "user", "content": f"Repair JSON error: {exc}"}]
        raise ValueError(f"Structured output repair exhausted: {last_err}")

    def stream_chat(self, messages: list[str] | list[dict[str, str]]) -> list[str]:
        lines = self.fixtures.get("sse_stream_chunks", ['data: {"choices":[{"delta":{"content":"ok"}}]}', "data: [DONE]"])
        return parse_sse_lines(lines)

    def run_tool_loop(
        self,
        messages: list[dict[str, str]],
        tool_executor: Callable[[str, dict[str, Any]], dict[str, Any]],
        max_steps: int = 4,
    ) -> dict[str, Any]:
        case = self._find_case(messages)
        calls = list(case.get("tool_calls", []))[:max_steps]
        tool_outputs: list[dict[str, Any]] = []
        for call in calls:
            name = str(call.get("name", ""))
            args = call.get("arguments") or {}
            try:
                out = tool_executor(name, args)
                tool_outputs.append({"id": call.get("id"), "name": name, "ok": True, "result": out})
            except Exception as exc:
                tool_outputs.append({"id": call.get("id"), "name": name, "ok": False, "error": str(exc), "retryable": False})
        return {
            "answer": case.get("final_answer", "Done."),
            "tool_outputs": tool_outputs,
            "steps_executed": len(tool_outputs),
        }

    def embed(self, texts: list[str], dim: int = 16) -> list[list[float]]:
        vectors: list[list[float]] = []
        for text in texts:
            vec = [0.0] * dim
            for tok in text.lower().split():
                h = int(hashlib.sha256(tok.encode("utf-8")).hexdigest(), 16)
                vec[h % dim] += 1.0
            norm = math.sqrt(sum(v * v for v in vec)) or 1.0
            vectors.append([round(v / norm, 6) for v in vec])
        return vectors


class OpenAICompatibleLLMClient:
    """Zero-dependency OpenAI-compatible HTTP client with retries, backoff, streaming & JSON repair."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        model: str | None = None,
        timeout_s: float = 20.0,
        max_retries: int = 2,
    ) -> None:
        self.base_url = (base_url or os.getenv("LLM_BASE_URL") or "http://localhost:11434/v1").rstrip("/")
        self.api_key = api_key if api_key is not None else os.getenv("LLM_API_KEY", "")
        self.model = model or os.getenv("LLM_MODEL") or "qwen2.5:7b-instruct"
        self.timeout_s = timeout_s
        self.max_retries = max_retries

    def _post(self, endpoint: str, body: dict[str, Any]) -> dict[str, Any]:
        url = f"{self.base_url}/{endpoint.lstrip('/')}"
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        payload = json.dumps(body).encode("utf-8")
        last_exc: Exception | None = None
        for attempt in range(self.max_retries + 1):
            req = urllib.request.Request(url, data=payload, headers=headers, method="POST")
            try:
                with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                    return json.loads(resp.read().decode("utf-8"))
            except urllib.error.HTTPError as exc:
                last_exc = exc
                if exc.code in (429, 502, 503, 504) and attempt < self.max_retries:
                    time.sleep(0.25 * (2**attempt) + random.uniform(0.0, 0.1))
                    continue
                raise
            except (urllib.error.URLError, TimeoutError) as exc:
                last_exc = exc
                if attempt < self.max_retries:
                    time.sleep(0.25 * (2**attempt))
                    continue
                raise
        raise RuntimeError(f"LLM request failed after retries: {last_exc}")

    def chat(self, messages: list[dict[str, str]], **kwargs: Any) -> LLMResult:
        t0 = time.perf_counter()
        data = self._post("chat/completions", {"model": self.model, "messages": messages, **kwargs})
        latency = (time.perf_counter() - t0) * 1000.0
        choice = (data.get("choices") or [{}])[0].get("message") or {}
        usage = data.get("usage") or {}
        cached = (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0)
        return LLMResult(
            content=choice.get("content") or "",
            model=data.get("model", self.model),
            latency_ms=round(latency, 2),
            prompt_tokens=int(usage.get("prompt_tokens", 0)),
            completion_tokens=int(usage.get("completion_tokens", 0)),
            cached_tokens=int(cached),
            tool_calls=list(choice.get("tool_calls") or []),
            mode="live",
        )

    def chat_structured(self, messages: list[dict[str, str]], required_keys: list[str], max_repairs: int = 2) -> tuple[dict[str, Any], LLMResult]:
        last_err: Exception | None = None
        msgs = list(messages)
        for _ in range(max_repairs + 1):
            res = self.chat(msgs, temperature=0)
            try:
                return validate_json_keys(res.content, required_keys), res
            except (json.JSONDecodeError, ValueError) as exc:
                last_err = exc
                msgs.append({"role": "assistant", "content": res.content})
                msgs.append({"role": "user", "content": f"Return ONLY valid JSON fixing error: {exc}"})
        raise ValueError(f"Live structured output failed: {last_err}")

    def embed(self, texts: list[str], model: str | None = None) -> list[list[float]]:
        data = self._post("embeddings", {"model": model or os.getenv("LLM_EMBED_MODEL", "nomic-embed-text"), "input": texts})
        return [row["embedding"] for row in data.get("data", [])]


def select_llm_client(fixture_path: str | Path = "fixtures/recorded_llm.json") -> MockReplayLLMClient | OpenAICompatibleLLMClient:
    mode = os.getenv("LLM_MODE", "offline_fixture").strip().lower()
    if mode == "live":
        return OpenAICompatibleLLMClient()
    return MockReplayLLMClient(fixture_path=fixture_path)
