import unittest

from eval_stats import bootstrap_mean_delta_ci
from llm_client import MockReplayLLMClient, parse_sse_lines
from security_scan import run_injection_checks, scan_repo_for_secrets
from telemetry import CostLedger
from vector_ops import cosine_similarity, reciprocal_rank_fusion, stage2_rerank


class RealBuildKitTests(unittest.TestCase):
    def test_sse_stream_parsing(self) -> None:
        client = MockReplayLLMClient()
        chunks = client.stream_chat([{"role": "user", "content": "stream"}])
        self.assertEqual("".join(chunks), "Verified policy response.")

    def test_structured_json_repair_loop(self) -> None:
        client = MockReplayLLMClient()
        parsed, res = client.chat_structured(
            [{"role": "user", "content": "bad_json_first return policy"}],
            required_keys=["answer", "citations", "confidence"],
        )
        self.assertIn("doc_1", parsed["citations"])
        self.assertEqual(res.mode, "offline_fixture")

    def test_multi_tool_loop_with_error_contract(self) -> None:
        client = MockReplayLLMClient()

        def executor(name: str, args: dict) -> dict:
            if name == "check_stock_sku":
                raise RuntimeError("inventory_timeout")
            return {"order_id": args["order_id"], "status": "shipped"}

        out = client.run_tool_loop([{"role": "user", "content": "tool_order_lookup ORD-1001"}], executor)
        self.assertEqual(out["steps_executed"], 2)
        self.assertTrue(out["tool_outputs"][0]["ok"])
        self.assertFalse(out["tool_outputs"][1]["ok"])
        self.assertEqual(out["tool_outputs"][1]["error"], "inventory_timeout")

    def test_cost_ledger_and_budget_guard(self) -> None:
        ledger = CostLedger(daily_budget_usd=0.01)
        cost = ledger.record("replay-small-fast", prompt_tokens=420, completion_tokens=38, latency_ms=44.0, cached_tokens=256)
        self.assertGreater(cost, 0.0)
        summary = ledger.summary()
        self.assertEqual(summary["p95_ms"], 44.0)
        with self.assertRaises(RuntimeError):
            ledger.record("frontier-reasoning", prompt_tokens=50000, completion_tokens=5000, latency_ms=900.0)

    def test_hybrid_rrf_rerank_and_bootstrap_ci(self) -> None:
        fused = reciprocal_rank_fusion([["d2", "d1"], ["d1", "d3"]])
        self.assertEqual(fused[0], "d1")
        self.assertAlmostEqual(cosine_similarity([1.0, 0.0], [1.0, 0.0]), 1.0)
        reranked = stage2_rerank("sku E-402 refund", [
            {"id": "a", "text": "general greeting page", "semantic_sim": 0.9},
            {"id": "b", "text": "sku E-402 refund policy is 14 days", "semantic_sim": 0.7},
        ], top_k=1)
        self.assertEqual(reranked[0]["id"], "b")
        mean_d, lo, hi = bootstrap_mean_delta_ci([0.5, 0.6, 0.5, 0.7], [0.8, 0.9, 0.85, 0.95])
        self.assertGreater(mean_d, 0.2)
        self.assertGreater(lo, 0.0)
        self.assertGreaterEqual(hi, lo)

    def test_security_scan_and_injection_suite(self) -> None:
        self.assertEqual(scan_repo_for_secrets("."), [])
        self.assertTrue(run_injection_checks())


if __name__ == "__main__":
    unittest.main()
